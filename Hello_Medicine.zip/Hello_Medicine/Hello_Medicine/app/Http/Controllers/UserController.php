<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Medicine;
use App\Models\Order;

class UserController extends Controller
{
    public function profile()
    {
        // get user from session
        $user = auth()->user();
        // search user from database
        $user = User::where('name', $user->name)->first();
        // return view with user
        return view('user.profile', compact('user'));
    }
    public static function getNamebyId($id)
    {
        // search user from database
        $user = User::where('id_user', $id)->first();
        // return user name
        return $user->name;
    }
    public static function getLocationbyId($id)
    {
        // search user from database
        $user = User::where('id_user', $id)->first();
        // return user location
        return $user->location;
    }
    public function addcart(Request $request)
    {
        // assign data from request
        $data = $request->all();
        $data['bank'] = 'null';
        $data['bank_num'] = 0;
        // add status
        $data['status'] = 'cart';
        // add user_id
        $data['user_id'] = Auth::user()->id_user;
        // add data to order
        Order::create($data);
        // return to detail product
        return redirect()->back()->with('success', 'Berhasil menambahkan ke keranjang!');
    }
    public function order()
    {
        // get user from session
        $user = auth()->user();
        // search user from database
        $user = User::where('name', $user->name)->first();
        // search user's orders from database
        $orders = Order::where('user_id', $user->id_user)->get();
        // return view with user and orders
        return view('user.order', compact('user', 'orders'));
    }
    public function success()
    {
        // get user from session
        $user = auth()->user();
        // search user from database
        $user = User::where('name', $user->name)->first();
        // search user's orders from database
        $orders = Order::where('user_id', $user->id_user)->get();
        // return view with user and orders
        return view('user.success', compact('user', 'orders'));
    }
    public static function getMedicine($id)
    {
        $medicine = Medicine::where('id', $id)->first();
        return $medicine;
    }
    public function cancelOrder($id)
    {
        $order = Order::where('id', $id)->first();
        $order->delete();
        return redirect()->back()->with('error', 'Pesanan dibatalkan');
    }
    // checkout
    public function checkout(Request $request,$id)
    {
        // search order from id
        $order = Order::where('id', $id)->first();
        // set bank and bank_num to database
        $order->bank = $request->bank;
        $order->bank_num = $request->bank_num;
        // set status to checkout
        $order->status = 'pending';
        // update order
        $order->save();
        // redirect to myorder
        return redirect()->route('myorder')->with('success', 'Pesanan berhasil di checkout');
    }
    public function edit(Request $request)
    {
        // search user from database
        $user = User::where('id_user', $request->id_user)->first();
        // save new data from all request
        $user->update($request->all());
        // return to profile
        return redirect()->back()->with('success', 'Berhasil mengubah data');
    }
}
