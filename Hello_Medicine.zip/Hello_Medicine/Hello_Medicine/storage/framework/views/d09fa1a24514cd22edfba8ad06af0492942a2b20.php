<!-- extend layout -->

<?php $__env->startSection('title' , 'User Order'); ?>
<?php $__env->startSection('content'); ?>
<body style="font-family: 'Nunito', sans-serif; background-image:url('http://127.0.0.1:8000/images/landing.jpg'); background-size:cover;">

<!-- content -->
<div class="container mb-5">
    <h2 class="text-danger text-center mt-5 fw-bolder">Keranjang</h2>
    <p class="fs-6 mb-5 text-center text-secondary">Segera lakukan konfirmasi agar barang segera dikirim</p>
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="true" href="<?php echo e(route('myorder')); ?>"> <span><i class="fa-solid fa-bell"></i></span> Berlangsung</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('myorder.success')); ?>"> <span><i class="fa-solid fa-check"></i></span> Berhasil</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <!-- all order -->
            <div class="row">
                <?php $__currentLoopData = $orders->sortByDesc('status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($order->status == 'pending' || $order->status == 'cart'): ?>
                <!-- get product form product id call function-->
                <?php
                    $medicine = App\Http\Controllers\UserController::getMedicine($order->product_id);
                ?>
                <div class="col-md-12 my-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3 d-flex justify-content-center align-items-center">
                                    <img src="<?php echo e(url('/images/medicines/'.$medicine->image)); ?>" style="max-height: 150px;" alt="">
                                </div>
                                <div class="col-md-8 align-self-center">
                                    <div class="d-flex flex-row justify-content-between">
                                        <div class="text-start">
                                            <a href="<?php echo e(route('medicine.show', $medicine->id)); ?>" class="card-title mb-3 text-primary fw-bold fs-4" style="text-decoration: none;"><?php echo e($medicine->name); ?></a>
                                            <div class="card-text mb-2">Jumlah : <?php echo e($order->quantity); ?> pcs</div>
                                            <div class="card-text mb-2">Total : <span class="text-success fw-bold">Rp. <?php echo e(number_format($order->quantity * $medicine->price)); ?></span></div>
                                            <div class="card-text">Ditambahkan Pada : <span class="text-secondary"><?php echo e($order->created_at); ?></span></div>
                                        </div>
                                        <div class="align-self-center">
                                            <?php if($order->status == 'pending'): ?>
                                                <div class="text-secondary">Menunggu Konfirmasi</div>
                                            <?php else: ?>
                                            <div class="col">
                                                <a type="button" data-bs-toggle="modal" data-bs-target="#checkout-<?php echo e($order->id); ?>" class="my-3 d-flex justify-content-center align-items-center shadow text-white" style="text-decoration:none; height:40px; width:120px; background-color: green; border: none; padding: 7px 26px; border-radius: 10px;">
                                                    <i class="fa-solid fa-cart-arrow-down"></i><span class="mx-1">Checkout</span>
                                                </a>
                                                <a type="button" data-bs-toggle="modal" data-bs-target="#cancel-<?php echo e($order->id); ?>" class="my-3 d-flex justify-content-center align-items-center shadow text-white" style="text-decoration:none; height:40px; width:120px; background-color: #f3004e; border: none; padding: 7px 26px; border-radius: 10px;">
                                                    <i class="fa-solid fa-xmark"></i></i><span class="mx-1">Batalkan</span>
                                                </a>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal Cancel -->
                <div class="modal fade" id="cancel-<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Batalkan Order?</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <a href="<?php echo e(route('medicine.show', $medicine->id)); ?>" class="card-title mb-3 text-primary fw-bold fs-4" style="text-decoration: none;"><?php echo e($medicine->name); ?></a>
                        <div class="card-text mb-2">Jumlah : <?php echo e($order->quantity); ?> pcs</div>
                        <div class="card-text mb-2">Total : <span class="text-success fw-bold">Rp. <?php echo e(number_format($order->quantity * $medicine->price)); ?></span></div>
                        <div class="card-text">Ditambahkan Pada : <span class="text-secondary"><?php echo e($order->created_at); ?></span></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Kembali</button>
                        <a href="<?php echo e(route('cancelorder', $order->id)); ?>" type="button" class="btn btn-danger">Konfirmasi</a>
                    </div>
                    </div>
                </div>
                </div>
                <!-- Modal Checkout -->
                <div class="modal fade" id="checkout-<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Checkout?</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <a href="<?php echo e(route('medicine.show', $medicine->id)); ?>" class="card-title mb-3 text-primary fw-bold fs-4" style="text-decoration: none;"><?php echo e($medicine->name); ?></a>
                                <div class="card-text mb-2">Jumlah : <?php echo e($order->quantity); ?> pcs</div>
                                <div class="card-text mb-2">Total : <span class="text-success fw-bold">Rp. <?php echo e(number_format($order->quantity * $medicine->price)); ?></span></div>
                                <div class="card-text">Ditambahkan Pada : <span class="text-secondary"><?php echo e($order->created_at); ?></span></div>
                                <hr>
                                <!-- admin's bank -->
                                <div class="fs-5">Nomor Rekening Transfer : <span class="text-danger">0812521535</span><span class="text-secondary fs-6 align-self-center"> (A/N AdminHM)</span></div>
                                <div class="text-secondary fs-6 align-self-center"> (HubungiAdmin Ke no : 082126738943)</span></div>
                                <hr>
                                <!-- form bank and bank_num -->
                                <form action="<?php echo e(route('checkout', $order->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <!-- bank -->
                                    <div class="form-group">
                                        <label for="bank">Bank</label>
                                        <input type="text" class="form-control" id="bank" name="bank" placeholder="Masukkan nama bank anda">
                                    </div>
                                    <!-- bank_num -->
                                    <div class="form-group">
                                        <label for="bank_num">Nomor Rekening</label>
                                        <input type="text" class="form-control" id="bank_num" name="bank_num" placeholder="Masukkan nomor rekening anda">
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Kembali</button>
                                <button type="submit" class="btn btn-success">Konfirmasi</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Hello_Medicine\Hello_Medicine\resources\views/user/order.blade.php ENDPATH**/ ?>