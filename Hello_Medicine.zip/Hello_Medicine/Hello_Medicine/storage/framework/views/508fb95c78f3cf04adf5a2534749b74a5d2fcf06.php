<!-- extend layout -->

<?php $__env->startSection('title' , 'User Profile'); ?>
<?php $__env->startSection('content'); ?>
<body style="font-family: 'Nunito', sans-serif; background-image:url('http://127.0.0.1:8000/images/landing.jpg'); background-size:cover;">

<!-- content -->
<div class="container">
    <!-- profile -->
    <div class="row my-5">
        <div class="col-md-5 align-self-center">
            <?php if($user->gender=='laki'): ?>
                <img src="<?php echo e(url('/images/user.png')); ?>" style="border-radius: 10%; max-height:600px;" loading=”lazy” class="card-img-top shadow" alt="...">
            <?php else: ?>
                <img src="<?php echo e(url('/images/user2.png')); ?>" style="border-radius: 10%; max-height:600px;" loading=”lazy” class="card-img-top shadow" alt="...">
            <?php endif; ?>
        </div>
        <div class="col-md-7 align-self-center">
            <div class="col">
                <!-- user data -->
                <div class="card p-2 shadow">
                    <div class="card-body">
                        <p class="fw-bold fs-5">Username</p>
                        <hr>
                        <p class="card-text"><?php echo e($user->username); ?></p>
                        <p class="fw-bold fs-5">Nama</p>
                        <p class="card-text"><?php echo e($user->name); ?></p>
                        <hr>
                        <p class="fw-bold fs-5">Gender</p>
                        <p class="card-text"><?php echo e($user->gender); ?></p>
                        <hr>
                        <p class="fw-bold fs-5">Alamat</p>
                        <p class="card-text"><?php echo e($user->location); ?></p>
                    </div>
                </div>
            </div>
            <!-- edit button -->
            <div class="col my-3 text-end">
                <a type="button" class="btn btn-warning text-white btn-block" data-bs-toggle="modal" data-bs-target="#staticBackdropedit">Edit Profile</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="staticBackdropedit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Edit Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- form -->
        <form action="<?php echo e(route('profile.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_user" value="<?php echo e($user->id_user); ?>">
            <!-- username -->
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>">
            </div>
            <!-- nama -->
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
            </div>
            <!-- gender -->
            <div class="form-group">
                <label for="gender">Jenis Kelamin</label>
                <select class="form-select" name="gender" id="gender">
                    <option value="laki">Laki Laki</option>
                    <option value="perempuan">Perempuan</option>
                </select>    
            </div>
            <!-- location -->
            <div class="form-group">
                <label for="location">Alamat</label>
                <input type="text" class="form-control" id="location" name="location" value="<?php echo e($user->location); ?>">
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-warning text-white">Edit</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Hello_Medicine\Hello_Medicine\resources\views/user/profile.blade.php ENDPATH**/ ?>