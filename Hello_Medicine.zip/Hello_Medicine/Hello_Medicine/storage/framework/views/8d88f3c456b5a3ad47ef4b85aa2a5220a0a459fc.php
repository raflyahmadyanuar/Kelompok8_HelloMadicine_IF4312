<nav class="navbar my-4 d-lg-block d-none">
    <div class="container">
        <a href="<?php echo e(route('landing')); ?>" style="text-decoration: none;" class="d-flex flex-row align-items-center justify-content-center">
            <img class="mx-2" src="<?php echo e(url('images/logo.png')); ?>" height="50px">
            <div class="fs-4 fw-bold">Hello Medicine</div>
            <?php if(Auth::check()): ?>
            <?php if(Auth::user()->role == 'admin'): ?>
                <div class="mx-1 text-danger fw-bold mb-1">Admin</div>
            <?php endif; ?>
            <?php endif; ?>
        </a>
        <ul class="nav justify-content-center fs-5">
            <li class="nav-item mx-2">
                <!-- give active link to the current page -->
                <a class="nav-link <?php echo e(Request::url() == ('http://localhost:8000/landing') ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('landing')); ?>">Home</a>
            </li>
            <li class="nav-item mx-2">
                <a class="nav-link <?php echo e(Request::url() == ('http://localhost:8000/medicine') || Request::route()->uri == 'medicine/show/{id}' || Request::route()->uri == 'medicine/search' ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('medicine')); ?>">Medicine</a>
            </li>
            <?php if(Auth::check()): ?>
            <?php if(Auth::user()->role == 'admin'): ?>
            <li class="nav-item mx-2">
                <a class="nav-link position-relative <?php echo e(Request::url() == ('http://localhost:8000/orders') ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('orders')); ?>">Pesanan
                    <span class="position-absolute top-20 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php
                        $order = App\Http\Controllers\OrderController::getOrderCount();
                    ?>
                        <?php echo e($order); ?>

                        <span class="visually-hidden">New Order</span>
                    </span>
                </a>
            </li>
            <?php else: ?>
            <li class="nav-item mx-2">
                <a class="nav-link position-relative <?php echo e(Request::url() == ('http://localhost:8000/myorder') ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('myorder')); ?>">Keranjang
                    <span class="position-absolute top-20 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php
                        $order = App\Http\Controllers\OrderController::getUserOrderCount();
                    ?>
                        <?php echo e($order); ?>

                        <span class="visually-hidden">New Order</span>
                    </span>
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
        </ul>
        <!-- search form -->
        <form action="<?php echo e(route('medicine.search')); ?>" method="POST" class="form-inline d-flex my-2 my-lg-0">
            <?php echo csrf_field(); ?>
            <input class="form-control mr-sm-2 mx-2" name="name" type="text" placeholder="Search Medicine" aria-label="Search">
            <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
        </form>
        <!-- user -->
        <!-- get session user and role -->
        <?php if(Auth::check()): ?>
            <div class="d-flex flex-row align-items-center justify-content-end">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle"></i> <span class="mx-2"><?php echo e(Auth::user()->name); ?></span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profil</a></li>
                        <?php if(Auth::user()->role == 'admin'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('orders')); ?>">Pesanan</a></li>
                        <?php else: ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('myorder')); ?>">Keranjang</a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>
        <?php else: ?>
            <div class="d-flex flex-row align-items-center justify-content-end">
                <div class="dropdown">
                    <button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle"></i> <span class="mx-2">Login</span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('login')); ?>">Login</a></li>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
</nav>
<nav class="navbar my-4 d-lg-none d-block d-flex">
    <div class="container d-flex flex-column justify-content-center align-items-center">
        <a href="<?php echo e(route('landing')); ?>" style="text-decoration: none;" class="d-flex flex-row align-items-center justify-content-center">
            <img class="mx-2" src="<?php echo e(url('images/logo.png')); ?>" height="50px">
            <div class="fs-4 fw-bold">Hello Medicine</div>
            <?php if(Auth::check()): ?>
            <?php if(Auth::user()->role == 'admin'): ?>
                <div class="mx-1 text-danger fw-bold mb-1">Admin</div>
            <?php endif; ?>
            <?php endif; ?>
        </a>
        <ul class="nav justify-content-center fs-6">
            <li class="nav-item mx-2">
                <!-- give active link to the current page -->
                <a class="nav-link <?php echo e(Request::url() == ('http://localhost:8000/landing') ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('landing')); ?>">Home</a>
            </li>
            <li class="nav-item mx-2">
                <a class="nav-link <?php echo e(Request::url() == ('http://localhost:8000/medicine') || Request::route()->uri == 'medicine/show/{id}' || Request::route()->uri == 'medicine/search' ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('medicine')); ?>">Medicine</a>
            </li>
            <?php if(Auth::check()): ?>
            <?php if(Auth::user()->role == 'admin'): ?>
            <li class="nav-item mx-2">
                <a class="nav-link position-relative <?php echo e(Request::url() == ('http://localhost:8000/orders') ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('orders')); ?>">Pesanan
                    <span class="position-absolute top-20 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php
                        $order = App\Http\Controllers\OrderController::getOrderCount();
                    ?>
                        <?php echo e($order); ?>

                        <span class="visually-hidden">New Order</span>
                    </span>
                </a>
            </li>
            <?php else: ?>
            <li class="nav-item mx-2">
                <a class="nav-link position-relative <?php echo e(Request::url() == ('http://localhost:8000/myorder') ? 'active' : 'text-dark'); ?>" href="<?php echo e(route('myorder')); ?>">Keranjang
                    <span class="position-absolute top-20 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php
                        $order = App\Http\Controllers\OrderController::getUserOrderCount();
                    ?>
                        <?php echo e($order); ?>

                        <span class="visually-hidden">New Order</span>
                    </span>
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
        </ul>
        <!-- search form -->
        <form action="<?php echo e(route('medicine.search')); ?>" method="POST" class="form-inline d-flex my-2 my-lg-0">
            <?php echo csrf_field(); ?>
            <div class="input-group input-group-sm mb-3">
                <input class="form-control mr-sm-2 mx-2" name="name" type="text" placeholder="Search Medicine" aria-label="Search">
                <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
            </div>
        </form>
        <!-- user -->
        <!-- get session user and role -->
        <?php if(Auth::check()): ?>
            <div class="d-flex flex-row align-items-center justify-content-end">
                <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle"></i> <span class="mx-2"><?php echo e(Auth::user()->name); ?></span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profil</a></li>
                        <?php if(Auth::user()->role == 'admin'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('orders')); ?>">Pesanan</a></li>
                        <?php else: ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('myorder')); ?>">Keranjang</a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>
        <?php else: ?>
            <div class="d-flex flex-row align-items-center justify-content-end">
                <div class="dropdown">
                    <button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle"></i> <span class="mx-2">Login</span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('login')); ?>">Login</a></li>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
</nav><?php /**PATH D:\Software\xampp\htdocs\Hello_Medicine\resources\views/layout/navbar.blade.php ENDPATH**/ ?>